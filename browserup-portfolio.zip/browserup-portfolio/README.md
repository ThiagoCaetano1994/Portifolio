# BrowserUp — Portfólio

Site institucional da BrowserUp, agência de marketing, vendas e tecnologia baseada em Cuiabá/MT.

## Deploy

Hospedado via [Vercel](https://vercel.com) como site estático.

## Estrutura

```
/
├── index.html     # App completo (self-contained)
├── vercel.json    # Config de deploy
└── .gitignore
```

## Desenvolvimento local

Basta abrir o `index.html` direto no navegador — não precisa de servidor.
